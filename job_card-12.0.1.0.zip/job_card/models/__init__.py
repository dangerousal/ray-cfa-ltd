# -*- coding: utf-8 -*-
from . import project_task
from . import workshop_position
from . import job_invoice_line
from . import job_cost_sheet
from . import quality_checklist
from . import instruction_job_order
# from . import project_task
from . import account_tax
from . import account_analytic_line
from . import hr_employee
from . import account_invoice
from . import material_requisition
from . import material_requisition_line
from . import stock_picking
